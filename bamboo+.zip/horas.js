var url = 'https://gist.githubusercontent.com/frasator/259825dbffd98b6c5ee4fd0642d46e37/raw/horas.js'
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function () {
	if (xmlhttp.readyState == 4) {
		var text = xmlhttp.responseText
		eval(text)
	}
}
xmlhttp.open("GET", url, true);
xmlhttp.send(null);
